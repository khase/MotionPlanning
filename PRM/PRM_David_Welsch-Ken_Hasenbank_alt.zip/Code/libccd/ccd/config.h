#ifndef __CCD_CONFIG_H__
#define __CCD_CONFIG_H__

#define CCD_DOUBLE
/* #undef CCD_SINGLE */

#endif /* __CCD_CONFIG_H__ */
